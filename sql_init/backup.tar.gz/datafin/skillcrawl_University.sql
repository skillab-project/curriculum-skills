-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 195.251.210.147    Database: skillcrawl
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `University`
--

DROP TABLE IF EXISTS `University`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `University` (
  `university_id` int NOT NULL AUTO_INCREMENT,
  `university_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`university_id`),
  UNIQUE KEY `uq_university` (`university_name`,`country`),
  KEY `idx_university_name` (`university_name`)
) ENGINE=InnoDB AUTO_INCREMENT=98 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `University`
--

LOCK TABLES `University` WRITE;
/*!40000 ALTER TABLE `University` DISABLE KEYS */;
INSERT INTO `University` VALUES (1,'Aarhus University','Denmark','2025-08-15 21:51:35'),(2,'Aalto University','Finland','2025-08-15 21:59:43'),(3,'Aristotle University of Thessaloniki','Greece','2025-08-15 22:09:17'),(4,'Akademie der bildenden Künste Wien','Austria','2025-08-15 22:09:17'),(5,'Arcadia College','Unknown','2025-08-15 22:09:17'),(6,'Blekinge Institute of Technology','Sweden','2025-08-15 22:22:07'),(7,'Brunel University Uxbridge','United Kingdom','2025-08-15 22:22:07'),(8,'Bocconi University','Italy','2025-08-15 22:22:07'),(9,'Chalmers University of Technology','Sweden','2025-08-15 22:23:55'),(10,'College of William and Mary','Unknown','2025-08-15 22:25:31'),(11,'Copenhagen Business School','Denmark','2025-08-15 22:25:31'),(12,'Cranfield University','United Kingdom','2025-08-15 22:25:31'),(13,'Delft University of Technology','Netherlands','2025-08-15 22:27:01'),(14,'EPFL - EPF Lausanne','Switzerland','2025-08-15 22:27:01'),(15,'ETHZ - ETH Zurich','Switzerland','2025-08-15 22:36:07'),(16,'Eberhard-Karls-Universität Tübingen','Germany','2025-08-15 22:36:07'),(17,'Eindhoven University of Technology','Netherlands','2025-08-15 22:36:07'),(18,'Freie Universität Berlin','Germany','2025-08-15 23:18:59'),(19,'Fachhochschule Stuttgart, Hochschule der Medien','Germany','2025-08-15 23:18:59'),(20,'Glasgow School of Art','United Kingdom','2025-08-15 23:18:59'),(21,'Friedrich-Alexander Universität Erlangen-Nürnberg','Germany','2025-08-15 23:18:59'),(22,'Göteborg University','Sweden','2025-08-15 23:18:59'),(23,'Imperial College London','United Kingdom','2025-08-15 23:20:29'),(24,'Universidade Comunitária da Região de Chapecó - Unochapecó','France','2025-08-15 23:20:29'),(25,'International Hellenic University','Greece','2025-08-15 23:20:29'),(26,'Johannes Kepler Universität Linz','Austria','2025-08-15 23:22:00'),(27,'KTH Royal Institute of Technology','Sweden','2025-08-15 23:27:38'),(28,'Karlsruher Institut für Technologie','Unknown','2025-08-15 23:34:30'),(29,'Katholieke Universiteit Leuven','Belgium','2025-08-15 23:34:30'),(30,'Lappeenranta University of Technology','Finland','2025-08-15 23:34:30'),(31,'King\'s College London, University of London','United Kingdom','2025-08-15 23:34:30'),(32,'London School of Economics and Political Science, University of London','United Kingdom','2025-08-15 23:34:30'),(33,'Loughborough University','United Kingdom','2025-08-15 23:34:30'),(34,'Ludwig-Maximilians-Universität München','Germany','2025-08-15 23:34:30'),(35,'Macquarie University','Unknown','2025-08-15 23:36:24'),(36,'Massachusetts Institute of Technology','Unknown','2025-08-15 23:36:24'),(37,'Mälardalen University','Sweden','2025-08-15 23:36:24'),(38,'Queen Mary, University of London','United Kingdom','2025-08-15 23:36:24'),(39,'Otto-Friedrich Universität Bamberg','Germany','2025-08-15 23:36:24'),(40,'Sheffield Hallam University','United Kingdom','2025-08-15 23:36:24'),(41,'Radboud University','Netherlands','2025-08-15 23:36:24'),(42,'Newcastle University','United Kingdom','2025-08-15 23:36:24'),(43,'Roskilde University','Denmark','2025-08-15 23:36:24'),(44,'Rheinisch Westfälische Technische Hochschule Aachen','Germany','2025-08-15 23:36:24'),(45,'Rheinische Friedrich-Wilhelms Universität Bonn','Germany','2025-08-15 23:36:24'),(46,'Sorbonne Université - Faculté des Sciences (Paris VI)','France','2025-08-15 23:36:24'),(47,'The Queen\'s University Belfast','United Kingdom','2025-08-15 23:36:24'),(48,'Stockholm School of Economics','Sweden','2025-08-15 23:36:24'),(49,'Stanford University','Unknown','2025-08-15 23:36:24'),(50,'Technische Universität München','Germany','2025-08-15 23:36:24'),(51,'The University of Sheffield','United Kingdom','2025-08-15 23:38:09'),(52,'Universitas Gadjah Mada','Unknown','2025-08-15 23:40:51'),(53,'Universidade de Santiago de Compostela','Spain','2025-08-15 23:40:51'),(54,'University College Dublin','Ireland','2025-08-15 23:40:51'),(55,'Universiteit Gent','Belgium','2025-08-15 23:40:51'),(56,'University College London, University of London','United Kingdom','2025-08-15 23:42:42'),(57,'University of Amsterdam','Netherlands','2025-08-15 23:44:25'),(58,'University of Birmingham','United Kingdom','2025-08-15 23:50:30'),(59,'University of Bristol','United Kingdom','2025-08-15 23:50:30'),(60,'University of Cambridge','United Kingdom','2025-08-16 00:18:29'),(61,'University of Copenhagen','Denmark','2025-08-16 00:18:29'),(62,'University of Dublin, Trinity College','Ireland','2025-08-16 00:20:03'),(63,'University of Durham','United Kingdom','2025-08-16 00:20:03'),(64,'University of Edinburgh','United Kingdom','2025-08-16 00:20:03'),(65,'University of Exeter','United Kingdom','2025-08-16 00:20:03'),(66,'University of Glasgow','United Kingdom','2025-08-16 00:21:49'),(67,'University of Groningen','Netherlands','2025-08-16 00:38:25'),(68,'University of Helsinki','Finland','2025-08-16 00:38:25'),(69,'University of Leeds','United Kingdom','2025-08-16 00:40:01'),(70,'University of Liverpool','United Kingdom','2025-08-16 00:41:43'),(71,'University of Ljubljana','Germany','2025-08-16 01:04:13'),(72,'University of Luxemburg','Luxembourg','2025-08-16 01:04:13'),(73,'University of Macedonia','Greece','2025-08-16 01:04:13'),(74,'University of Michigan - Ann Arbor','Unknown','2025-08-16 01:05:57'),(75,'University of Manchester','United Kingdom','2025-08-16 01:05:57'),(76,'University of Nottingham','United Kingdom','2025-08-16 01:05:57'),(77,'University of Oslo','Norway','2025-08-16 01:05:57'),(78,'University of Oxford','United Kingdom','2025-08-16 01:09:26'),(79,'University of Roma \"La Sapienza\"','Italy','2025-08-16 01:09:26'),(80,'University of Southampton','United Kingdom','2025-08-16 01:13:52'),(81,'University of St. Andrews','United Kingdom','2025-08-16 01:13:52'),(82,'University of Turku','Finland','2025-08-16 01:27:09'),(83,'University of Strathclyde','United Kingdom','2025-08-16 01:27:09'),(84,'University of Warwick','United Kingdom','2025-08-16 01:27:09'),(85,'University of York','United Kingdom','2025-08-16 01:27:09'),(86,'University of Waterloo','Unknown','2025-08-16 01:27:09'),(87,'University of Vaasa','Finland','2025-08-16 01:27:09'),(88,'Universität Hohenheim','Germany','2025-08-16 01:28:51'),(89,'Universität Stuttgart','Germany','2025-08-16 01:28:51'),(90,'Universität Leipzig','Germany','2025-08-16 01:28:51'),(91,'Universität Vienna','Austria','2025-08-16 01:30:31'),(92,'Université d\'Aix-Marseille','France','2025-08-16 01:36:06'),(93,'Université de Strasbourg','France','2025-08-16 01:36:06'),(94,'Uppsala University','Sweden','2025-08-16 01:36:06'),(95,'Universität Zürich','Switzerland','2025-08-16 01:36:06'),(96,'Vrije Universiteit Amsterdam','Netherlands','2025-08-16 01:36:06'),(97,'Xi\'an Jiaotong-Liverpool University','Unknown','2025-08-16 01:36:22');
/*!40000 ALTER TABLE `University` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-16 18:25:03
