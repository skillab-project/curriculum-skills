-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 195.251.210.147    Database: skillcrawl
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Occupation`
--

DROP TABLE IF EXISTS `Occupation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Occupation` (
  `occupation_id` varchar(64) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  `parent_label` varchar(255) DEFAULT NULL,
  `top_sector` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`occupation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Occupation`
--

LOCK TABLES `Occupation` WRITE;
/*!40000 ALTER TABLE `Occupation` DISABLE KEYS */;
INSERT INTO `Occupation` VALUES ('http://data.europa.eu/esco/isco/C131','Production managers in agriculture, forestry and fisheries',NULL,NULL),('http://data.europa.eu/esco/isco/C1311','Agricultural and forestry production managers',NULL,NULL),('http://data.europa.eu/esco/isco/C21','Science and engineering professionals',NULL,NULL),('http://data.europa.eu/esco/isco/C211','Physical and earth science professionals',NULL,NULL),('http://data.europa.eu/esco/isco/C2114','Geologists and geophysicists',NULL,NULL),('http://data.europa.eu/esco/isco/C2131','Biologists, botanists, zoologists and related professionals',NULL,NULL),('http://data.europa.eu/esco/isco/C2132','Farming, forestry and fisheries advisers',NULL,NULL),('http://data.europa.eu/esco/isco/C2211','Generalist medical practitioners',NULL,NULL),('http://data.europa.eu/esco/isco/C2212','Specialist medical practitioners',NULL,NULL),('http://data.europa.eu/esco/isco/C2222','Midwifery professionals',NULL,NULL),('http://data.europa.eu/esco/isco/C2230','Traditional and complementary medicine professionals',NULL,NULL),('http://data.europa.eu/esco/isco/C2240','Paramedical practitioners',NULL,NULL),('http://data.europa.eu/esco/isco/C225','Veterinarians',NULL,NULL),('http://data.europa.eu/esco/isco/C2250','Veterinarians',NULL,NULL),('http://data.europa.eu/esco/isco/C2263','Environmental and occupational health and hygiene professionals',NULL,NULL),('http://data.europa.eu/esco/isco/C2266','Audiologists and speech therapists',NULL,NULL),('http://data.europa.eu/esco/isco/C232','Vocational education teachers',NULL,NULL),('http://data.europa.eu/esco/isco/C2320','Vocational education teachers',NULL,NULL),('http://data.europa.eu/esco/isco/C2424','Training and staff development professionals',NULL,NULL),('http://data.europa.eu/esco/isco/C2633','Philosophers, historians and political scientists',NULL,NULL),('http://data.europa.eu/esco/isco/C3111','Chemical and physical science technicians',NULL,NULL),('http://data.europa.eu/esco/isco/C3230','Traditional and complementary medicine associate professionals',NULL,NULL),('http://data.europa.eu/esco/isco/C3253','Community health workers',NULL,NULL),('http://data.europa.eu/esco/isco/C3512','Information and communications technology user support technicians',NULL,NULL),('http://data.europa.eu/esco/isco/C4132','Data entry clerks',NULL,NULL),('http://data.europa.eu/esco/isco/C4229','Client information workers not elsewhere classified',NULL,NULL),('http://data.europa.eu/esco/isco/C6111','Field crop and vegetable growers',NULL,NULL),('http://data.europa.eu/esco/isco/C6112','Tree and shrub crop growers',NULL,NULL),('http://data.europa.eu/esco/isco/C6113','Gardeners, horticultural and nursery growers',NULL,NULL),('http://data.europa.eu/esco/isco/C7321','Pre-press technicians',NULL,NULL),('http://data.europa.eu/esco/isco/C8341','Mobile farm and forestry plant operators',NULL,NULL);
/*!40000 ALTER TABLE `Occupation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-08-16 18:45:15
